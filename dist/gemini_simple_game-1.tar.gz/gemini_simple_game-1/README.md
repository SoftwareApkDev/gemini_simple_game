# gemini_simple_game

A simple game with Google Gemini AI integrated into it.

Pre-requisites:

1. [Python](https://www.python.org/downloads/) installed in your device.
2. .env file in the same directory as <GEMINI_SIMPLE_GAME_DIRECTORY> and has the value of GEMINI_API_KEY.

**Note:** Replace <GEMINI_SIMPLE_GAME_DIRECTORY> with the path to the directory of the game **Gemini Simple Game**.
